package com.example.grocerystore;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

// IMSystemApplication.java only needs to be run if the
// IMSsystem.fxml needs to be looked at.

// Please use InventoryLogin.java in order to run the
// whole program as you will break the code if you attempt
// to 'logout' using this one.

public class IMSystemApplication extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("IMSsystem.fxml"));
        Scene scene = new Scene(root);
        stage.setTitle("IMSystem");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }


}
