package com.example.grocerystore;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// Author: Omari Harvey
// Project Role: In charge of the GUI and JavaFx implementation as shown below
// Take the class or classes group members (Laura and Melissa) created and create
// a nice looking UI for the GUI. This Process took about a week to implement and create

public class IMSystemController implements Initializable {
    // item/product chart
    /**
     * Below are the buttons to modify the inventory table
     */
    @FXML
    private Button addItemButton;
    @FXML
    private Button clearEntryBtn;
    @FXML
    private Button deleteItemBtn;
    @FXML
    private Button updateItemBtn;
    /**
     * Below are the individual table columns for the inventory page
     */

    @FXML
    private TableColumn<Product, String> addItem_col_itemEntryDate;

    @FXML
    private TableColumn<Product, Double> addItem_col_itemPrice;

    @FXML
    private TableColumn<Product, Integer> addItem_col_itemID;

    @FXML
    private TableColumn<Product, String> addItem_col_itemName;

    @FXML
    private TableColumn<Product, Integer> addItem_col_itemQuantity;

    @FXML
    private TableColumn<Product, Integer> addItem_col_itemShelfLife;

    @FXML
    private TableColumn<Product, String> addItem_col_itemType;

    @FXML
    private TextField addItem_entryDate;

    @FXML
    private TextField addItem_itemPrice;

    @FXML
    private TextField addItem_itemID;

    @FXML
    private TextField addItem_itemName;

    @FXML
    private TextField addItem_itemQuantity;

    @FXML
    private TextField addItem_itemType;

    @FXML
    private TextField addItem_shelfLife;

    @FXML
    private TableView<Product> addItems_tableView;

    /**
     * The code below is an observable list that creates instances of the class Object Product variables to give the table starting values
     *
     */
    ObservableList<Product> list = FXCollections.observableArrayList(
            new Product("March 19", 11, "Apples", 45, 5, 123.76, "Produce"),
            new Product("March 19", 19, "Bananas", 45, 5, 226.66, "Produce"),
            new Product("March 19", 27, "Paper", 45, 46, 223.76, "Produce"),
            new Product("March 19", 35, "Markers", 45, 50, 163.76, "Produce")
    );


    // add button
    @FXML
    void setAddItemButton(ActionEvent event){
        /**
         * This method allows for the add button to function properly
         * It takes all the values the user inputs and creates a class instance of Products using those values
         * It then adds them to the table when the button is clicked and is displayed within that table
         */

       Product product = new Product(addItem_entryDate.getText(), Integer.parseInt(addItem_itemID.getText()),
                addItem_itemName.getText(), Integer.parseInt(addItem_itemQuantity.getText()),
                Integer.parseInt(addItem_shelfLife.getText()), Double.parseDouble(addItem_itemPrice.getText()),
                addItem_itemType.getText());
        ObservableList<Product> products = addItems_tableView.getItems();
        products.add(product);
        addItems_tableView.setItems(products);
    }

    @FXML
    void setDeleteItemBtn(ActionEvent event){
        /**
         * This method takes the selected row/index as an int and deletes it via the delete button when clicked
         */
        int selected = addItems_tableView.getSelectionModel().getSelectedIndex();
        addItems_tableView.getItems().remove(selected);
    }


    @FXML
    private Button home_btn;

    @FXML
    private Button inventoryButton;

    @FXML
    private Button logout_button;

    @FXML
    private AnchorPane itemInventory_Hub;

    @FXML
    private Button productsClearButton;


    @FXML
    private AnchorPane welcomeScreen;



    @FXML
    void togglePage(ActionEvent event) {
        /**
         *This method allows for switching between the two pages available within the system
         */
        if (event.getSource() == home_btn){
            welcomeScreen.setVisible(true);
            itemInventory_Hub.setVisible(false);
        }
        else if (event.getSource() == inventoryButton) {
            welcomeScreen.setVisible(false);
            itemInventory_Hub.setVisible(true);
        }
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle){
        /**
         * This method initializes and allows for the table to be filled with starting values
         */
        addItem_col_itemEntryDate.setCellValueFactory(new PropertyValueFactory<Product, String>("entryDate"));
        addItem_col_itemID.setCellValueFactory(new PropertyValueFactory<Product, Integer>("id"));
        addItem_col_itemName.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
        addItem_col_itemQuantity.setCellValueFactory(new PropertyValueFactory<Product, Integer>("quantity"));
        addItem_col_itemShelfLife.setCellValueFactory(new PropertyValueFactory<Product, Integer>("shelfLife"));
        addItem_col_itemPrice.setCellValueFactory(new PropertyValueFactory<Product, Double>("price"));
        addItem_col_itemType.setCellValueFactory(new PropertyValueFactory<Product, String>("itemType"));

        addItems_tableView.setItems(list);


    }

    @FXML
    void setUpdateItemBtn(ActionEvent event){
        /**
         * This method allows for the update button to grab a row using another method and
         * update any value the user may have made an error on
         */
        ObservableList<Product> currData = addItems_tableView.getItems();
        int currItemId = Integer.parseInt(addItem_itemID.getText());

        for (Product product : currData){
            if (product.getId() == currItemId) {
                product.setName(addItem_itemName.getText());
                product.setItemType(addItem_itemType.getText());
                product.setQuantity(Integer.parseInt(addItem_itemQuantity.getText()));
                product.setEntryDate(addItem_entryDate.getText());
                product.setShelfLife(Integer.parseInt(addItem_shelfLife.getText()));
                product.setPrice(Double.parseDouble(addItem_itemPrice.getText()));

                addItems_tableView.setItems(currData);
                addItems_tableView.refresh();
                break;
            }
        }
    }
    @FXML
    void selectedRow(MouseEvent event){
        /**
         * This method allows for the user to actually select the row to be updated in the setUpdateItemBtn method
         */
        Product selectedProduct = addItems_tableView.getSelectionModel().getSelectedItem();
        addItem_itemID.setText(String.valueOf(selectedProduct.getId()));
        addItem_itemName.setText(String.valueOf(selectedProduct.getName()));
        addItem_itemType.setText(String.valueOf(selectedProduct.getItemType()));
        addItem_entryDate.setText(String.valueOf(selectedProduct.getEntryDate()));
        addItem_itemQuantity.setText(String.valueOf(selectedProduct.getQuantity()));
        addItem_shelfLife.setText(String.valueOf(selectedProduct.getShelfLife()));
        addItem_itemPrice.setText(String.valueOf(selectedProduct.getPrice()));

    }
    @FXML
    void setClearItemBtn(ActionEvent event){
        /**
         * This method allows for the user to clear the text fields.
         */
        addItem_itemID.clear();
        addItem_itemName.clear();
        addItem_itemType.clear();
        addItem_entryDate.clear();
        addItem_shelfLife.clear();
        addItem_itemPrice.clear();
        addItem_itemQuantity.clear();
    }

    @FXML
    private void userLogout(ActionEvent event) throws IOException {

        /**
         * Method added later by Nex Humphrey
         * This method allows the user to logout of the scene and
         * will bring the user back to the login screen.
         */
        InventoryLogin change = new InventoryLogin();
        change.changeScene("InventoryLogin.fxml");
    }

    public void initialize(ActionEvent event) {
    }
}
