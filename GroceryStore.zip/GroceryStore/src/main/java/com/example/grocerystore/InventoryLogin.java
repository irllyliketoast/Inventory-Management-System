package com.example.grocerystore;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

// Login GUI created by Melissa Gomez and Nex Humphrey
// Author: Nex Humphrey
// Role: Build a login scene for the Inventory System Managements' main GUI
// file and connect the two programs together.

/**
 *
 * The below will run both the login scene and the inventory scene.
 * How scenes will change will be described in the programs comments/docstrings.
 *
 */
public class InventoryLogin extends Application {

    // Creating a private stage in order to switch scenes
    private static Stage stg;

    @Override
    public void start(Stage primaryStage) throws Exception {
        /**
         * This method will allow the user to see the scenes.
         */
        stg = primaryStage;
        Parent root = FXMLLoader.load(getClass().getResource("InventoryLogin.fxml"));
        primaryStage.setTitle("Inventory Management System");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public void changeScene(String fxml) throws IOException {
        /**
         * This method allows the user to switch between scenes depending
         * on what fxml title is given to it.
         */

        // Creating a new Parent in order to load the new scene
        Parent pane = FXMLLoader.load(getClass().getResource(fxml));

        // The program will then set the new scene, allowing the user
        // to view it
        stg.setScene(new Scene(pane));
    }

    public static void main(String[] args) {
        launch(args);
    }

}
