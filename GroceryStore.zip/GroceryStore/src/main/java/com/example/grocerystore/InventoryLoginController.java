package com.example.grocerystore;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.io.IOException;

// Login GUI created by Melissa Gomez and Nex Humphrey
// Author: Nex Humphrey
// Role: Build a login scene for the Inventory System Managements' main GUI
// file and connect the two programs together.

public class InventoryLoginController {
    /**
     * Below are the individual fields for the login screen.
     */
    @FXML
    private Button loginButton;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField;

    @FXML
    private Label incorrectLogin;

    @FXML
    private void login(ActionEvent event) throws IOException {
        /**
         * Clicking the login button will activate the checkingLogin() method.
         */
        checkingLogin();
    }

    private void checkingLogin() throws IOException{
        /**
         * This method checks to see if the given login information is correct.
         * If any of fields are empty or the information is incorrect, it
         * will let the user know. If the given information is correct,
         * the scene will change to the Inventory Management System Scene.
         */

        // Creating a new InventoryLogin() in order to switch scenes
        InventoryLogin change = new InventoryLogin();

        if (usernameField.getText().equals("adminUsername") && passwordField.getText().equals("adminPassword")) {

            // When the given information is correct, the program will
            // change the incorrectLogin label to state that the login
            // was successful
            incorrectLogin.setText("Login attempt was successful!");

            // The method will then run the changeScene() method
            // with the IMSsystem.fxml
            change.changeScene("IMSsystem.fxml");

        } else if (usernameField.getText().isEmpty() && passwordField.getText().isEmpty()) {
            // If either of the fields are empty, the program will change
            // the incorrectLogin label to state the user needs to add
            // their credentials to the field
            incorrectLogin.setText("Please enter in your credentials.");

        } else {
            // If the information given is not correct, the program will
            // change the incorrectLogin label to state the user needs to
            // put the correct information in
            incorrectLogin.setText("Wrong username or password.");

        }
    }
}
