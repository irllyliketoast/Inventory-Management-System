package com.example.grocerystore;

public class Product {
    // Product class representing individual products
    // product is the superclass
    // subclasses include daily products, weekly products, and month products
    // daily products extends products like milk
    // weekly products extends products like meat
    // monthly products extends products like toilet paper
    // each singular product like product price and identification number

    /**
     * @author Group 15 - Laura Estremera
     * Course: CSC 331-001
     * Date: 4/5/2024
     * Description: This represents the product as an object.
     *  This class included the item ID, the name of the item, the price of the item,
     *  and the quanity that has been sold from our grocery store.
     */
    private int id;
    private String name;
    private double price;
    private int quantity;
    private String entryDate;
    private int shelfLife;
    private String itemType;


    // Constructor
    public Product(){
        this.id = 0;
        this.name = "";
        this.price = 0.0;
        this.quantity = 0;
        this.entryDate = "";
        this.shelfLife = 0;
        this.itemType = "";
    }
    public Product(String entryDate, int id, String name, int quantity,
                   int shelfLife, double price,String itemType) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.entryDate = entryDate;
        this.shelfLife = shelfLife;
        this.itemType = itemType;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getEntryDate() { return entryDate; }

    public int getShelfLife() { return shelfLife; }

    public String getItemType() { return itemType; }

    // Setter methods
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setEntryDate(String entryDate) { this.entryDate = entryDate; }

    public void setShelfLife(int shelfLife) { this.shelfLife = shelfLife; }

    public void setItemType(String itemType) { this.itemType = itemType; }

}

